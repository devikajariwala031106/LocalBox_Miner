import { useEffect, useState } from 'react'
import RecordForm from './components/RecordForm'
import RecordList from './components/RecordList'

export default function App() {
  const [records, setRecords] = useState([])
  const [editItem, setEditItem] = useState(null)

  useEffect(() => {
    const stored = localStorage.getItem('localbox-records')
    if (stored) setRecords(JSON.parse(stored))
  }, [])

  useEffect(() => {
    localStorage.setItem('localbox-records', JSON.stringify(records))
  }, [records])

  const addRecord = (data) => {
    setRecords([...records, { ...data, id: Date.now() }])
  }

  const updateRecord = (data) => {
    setRecords(records.map(r => r.id === data.id ? data : r))
    setEditItem(null)
  }

  const deleteRecord = (id) => {
    setRecords(records.filter(r => r.id !== id))
  }

  const clearAll = () => {
    setRecords([])
  }

  return (
    <div className="container">
      <h1>LocalBox Miner</h1>

      <div className="stats">
        <span>Total Records: {records.length}</span>
        <span>Stored In Browser</span>
      </div>

      <RecordForm
        addRecord={addRecord}
        updateRecord={updateRecord}
        editItem={editItem}
      />

      <RecordList
        records={records}
        onEdit={setEditItem}
        onDelete={deleteRecord}
        onClear={clearAll}
      />
    </div>
  )
}
