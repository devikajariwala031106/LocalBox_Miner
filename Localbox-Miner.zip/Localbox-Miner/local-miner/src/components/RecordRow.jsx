export default function RecordRow({ item, onEdit, onDelete }) {
    return (
        <tr>
            <td>{item.name}</td>
            <td>{item.value}</td>
            <td>
                <button onClick={() => onEdit(item)}>Edit</button>
                <button onClick={() => onDelete(item.id)}>Delete</button>
            </td>
        </tr>
    )
}
