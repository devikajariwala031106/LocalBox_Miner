import RecordRow from './RecordRow'

export default function RecordList({ records, onEdit, onDelete, onClear }) {
    if (records.length === 0) {
        return <p className="empty">No Records Found</p>
    }

    return (
        <>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Value</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {records.map(item => (
                        <RecordRow
                            key={item.id}
                            item={item}
                            onEdit={onEdit}
                            onDelete={onDelete}
                        />
                    ))}
                </tbody>
            </table>

            <button className="clear" onClick={onClear}>
                Clear All Records
            </button>
        </>
    )
}
