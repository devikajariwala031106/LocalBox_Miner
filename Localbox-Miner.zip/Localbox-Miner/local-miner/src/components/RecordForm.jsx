import { useEffect, useState } from 'react'

export default function RecordForm({ addRecord, updateRecord, editItem }) {
    const [name, setName] = useState('')
    const [value, setValue] = useState('')
    const [error, setError] = useState('')

    useEffect(() => {
        if (editItem) {
            setName(editItem.name)
            setValue(editItem.value)
        }
    }, [editItem])

    const handleSubmit = (e) => {
        e.preventDefault()
        if (!name || !value) {
            setError('All fields required')
            return
        }

        if (editItem) {
            updateRecord({ ...editItem, name, value })
        } else {
            addRecord({ name, value })
        }

        setName('')
        setValue('')
        setError('')
    }

    return (
        <form onSubmit={handleSubmit} className="form">
            <input
                type="text"
                placeholder="Record Name"
                value={name}
                onChange={e => setName(e.target.value)}
            />
            <input
                type="text"
                placeholder="Record Value"
                value={value}
                onChange={e => setValue(e.target.value)}
            />
            <button>{editItem ? 'Update' : 'Add'}</button>
            {error && <p className="error">{error}</p>}
        </form>
    )
}
